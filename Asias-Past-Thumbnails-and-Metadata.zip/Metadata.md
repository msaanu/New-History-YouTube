# Asia’s Past — episode 1 launch package

## Three title and thumbnail pairs
A — Recommended starting option
Title: How Did Joseon Decide Who Became Queen?
Thumbnail: WHY HER?!
Angle: selection, curiosity and the central subject of the whole episode.

B
Title: Chosen as Queen: Why Her Whole Family Mattered
Thumbnail: CHOSEN TOO?!
Angle: the change in status for the bride’s family, matching the opening narration.

C
Title: How Joseon Chose a Queen—and Punished a Critic
Thumbnail: HE OBJECTED?!
Angle: the examination-essay controversy within the selection story. This is a secondary story, so A is the strongest overall match. Do not imply execution or imprisonment: the documented order removed Yi Gyu-wi from the scholar register.

## Ready-to-paste description
You have been chosen to become queen. Your father receives an appointment. Your mother receives a title. But how did the court decide it should be you?

Step inside Korea’s Joseon dynasty to explore the 1759 selection of Queen Jeongsun, King Yeongjo’s second queen. Through royal records and a carefully distinguished comparison with Lady Hyegyeong’s earlier selection as a crown prince’s bride, we follow family documents, successive selections, remembered preparations, and a criticism that brought a royal order against its author.

This episode asks: when a court chose a royal bride, how much did the decision change the lives of her family as well?

Whose perspective would you most want to hear—the woman chosen, her parents, or a candidate who went home? Tell us in the comments.

Subscribe to Asia’s Past for researched, illustrated stories of people across Asian history—from households and workplaces to royal courts.

RESEARCH & SOURCES

The Annals of King Yeongjo (National Institute of Korean History; record links below):
• Request for a royal marriage, 1759:
https://sillok.history.go.kr/id/kua_13505003_004
• Yeongjo’s explanation of the queen’s responsibilities:
https://sillok.history.go.kr/id/kua_13505004_001
• Candidate submissions in the 1743 crown-princess selection:
https://sillok.history.go.kr/id/kua_11908003_001
• Eight candidates advanced in 1743 (not the total applicant count):
https://sillok.history.go.kr/id/kua_11909029_001
• Three advanced; the others permitted to marry:
https://sillok.history.go.kr/id/kua_11910028_001
• Hong Bong-han’s daughter selected in 1743:
https://sillok.history.go.kr/id/kua_11911013_001
• The examination essay controversy, 1759:
https://sillok.history.go.kr/id/kua_13506004_001
• The king’s order against Yi Gyu-wi:
https://sillok.history.go.kr/id/kua_13506005_001
• Kim Han-gu’s daughter chosen at the third selection, 1759:
https://sillok.history.go.kr/id/kua_13506009_001
• Titles for her parents:
https://sillok.history.go.kr/id/kua_13506011_002
• Ordered reductions in wedding decorations and banquet arrangements:
https://sillok.history.go.kr/id/kua_13505007_002
• The queen’s investiture:
https://sillok.history.go.kr/id/kua_13506020_001

Lady Hyegyŏng, The Memoirs of Lady Hyegyŏng: The Autobiographical Writings of a Crown Princess of Eighteenth-Century Korea. Translated, introduced and annotated by JaHyun Kim Haboush; foreword by Dorothy Ko. University of California Press, 2013. ISBN 9780520280489.
Consulted: Introduction; Principal Persons; selection narrative in the Memoir of 1795 and accompanying notes XVII–XXI; 1759 wedding passage in the Memoir of 1805.
Publisher reference:
https://www.ucpress.edu/books/the-memoirs-of-lady-hyegyong/paper

SOURCE & ILLUSTRATION NOTE
Research used third-party digital transcriptions because the official and publisher sites were unavailable in the research environment. These copies were not independently checked against the official editions. The official links above identify the underlying records; they do not imply direct access during research.
Annals transcription consulted:
https://github.com/dhchoi02/JoseonTSI/tree/52ced1ab40baf7f97d21cd938e8b77cad37d450c
Memoir transcription provenance:
https://github.com/ThornboroughA/Hyegyong_Index/tree/d499cda6e46f8ecf4f2eb621ebcda26e951c70dd

Lady Hyegyeong’s recollections concern her own selection in 1743, not Queen Jeongsun’s private experiences in 1759. Annals dates use the historical lunar calendar. Illustrations are artistic reconstructions, not contemporary portraits or documentary footage. This is educational history, not commentary on present-day nations, faiths or political disputes.

#KoreanHistory #JoseonDynasty #AsiasPast

## Optional upload tags
Joseon dynasty, Korean history, Queen Jeongsun, King Yeongjo, Lady Hyegyeong, Joseon royal marriage, Korean queens, royal bride selection, gantaek, Asia’s Past, Asian history, illustrated history

## Testing notes
No title or thumbnail can guarantee virality. If YouTube Studio offers title-and-thumbnail tests, test these pairs together. If only thumbnail testing is available, keep title A fixed while testing all three thumbnails, then test title wording separately. Prefer native watch-time-based results over judging CTR alone; allow the test enough impressions and do not declare a winner from a handful of views. Avoid a mandatory one-week decision when traffic is limited.
The thumbnail expressions are conceptual illustrations of the stakes, not evidence of the historical subjects’ recorded emotions. No invented age gap, candidate count, execution or forced-marriage claim is used in this packaging.
